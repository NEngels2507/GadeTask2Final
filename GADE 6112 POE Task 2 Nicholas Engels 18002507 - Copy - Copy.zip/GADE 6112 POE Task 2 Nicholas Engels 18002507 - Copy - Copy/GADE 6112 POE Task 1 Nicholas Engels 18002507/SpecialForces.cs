﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_6112_POE_Task_1_Nicholas_Engels_18002507
{
    public class SpecialForces : Unit
    {
        public int xPos//This saves the X position of the Melee Unit
        {
            get { return XPos; }
            set { XPos = value; }
        }

        public int yPos//This saves the Y Position of the Melee Unit
        {
            get { return YPos; }
            set { YPos = value; }
        }

        public int health//This would save the health of the melee Unit which is capped at 20
        {
            get { return Health; }
            set { Health = value; }
        }

        public int speed //This is the speed that the Melee Unit is able to attack with
        {
            get { return Speed; }
            set { Speed = value; }
        }

        public int attack//This saves the amount of damage that the unit can inflict to the enemy
        {
            get { return Attack; }
            set { Attack = value; }
        }

        public int projectileRange//This is how close the melee unit has to be in order to attack
        {
            get { return Range; }
            set { Range = value; }
        }

        public int faction//This stores the allaigence of the unit
        {
            get { return Faction; }
            set { Faction = value; }
        }

        public string image // this is the colour of the team
        {
            get { return Image; }
            set { Image = value; }
        }

        public SpecialForces(int x, int y, int health, int attack, int speed, int range, int faction, string image)
        {
            xPos = x;
            yPos = y;
            Health = health;
            Speed = speed;
            Attack = attack;
            Range = range;
            Faction = faction;
            Image = image;
        }

        public override void Move(Direction d)
        {
            switch (d)
            {
                case Direction.North:
                    {
                        YPos -= Speed;
                        break;
                    }
                case Direction.East:
                    {
                        XPos += Speed;
                        break;
                    }
                case Direction.South:
                    {
                        YPos += Speed;
                        break;
                    }
                case Direction.West:
                    {
                        XPos -= Speed;
                        break;
                    }
            }
        }

        public override void Combat(Unit u)
        {
            if (u.GetType() == typeof(SpecialForces))
            {
                Health = ((SpecialForces)u).Attack;
            }
            //else if (u.GetType() == typeof(RangedClass))
            //{
            //    Health = ((RangedClass)u).Attack;
            //}
        }

        public override bool InRange(Unit u)
        {
            if (u.GetType() == typeof(SpecialForces))
            {
                SpecialForces m = (SpecialForces)u;
                if (DistanceTo(u) >= Range)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        public override Unit Closest(Unit[] units)
        {
            Unit closest = this;
            int closestDistance = 50;
            foreach (Unit u in units)
            {
                //if(u.GetHashCode() == typeof(MeleeUnit))
                //{
                if (((SpecialForces)u).Faction != Faction)
                {
                    if (DistanceTo((SpecialForces)u) < closestDistance)
                    {
                        closest = u;
                        closestDistance = DistanceTo((SpecialForces)u);
                    }
                }
                //}
                //else if (u.GetHashCode() == typeof(RangedClass))
                //{
                //    if (DistanceTo((RangedClass)u) < closestDistance)
                //    {
                //        closest = u;
                //        closestDistance = DistanceTo((RangedClass)u);
                //    }
                //}
            }
            return closest;
        }

        public override bool IsDead()
        {
            throw new NotImplementedException();
        }

        private int DistanceTo(Unit u)
        {
            if (u.GetType() == typeof(SpecialForces))
            {
                SpecialForces m = (SpecialForces)u;
                int d = Math.Abs(xPos - m.xPos) + Math.Abs(yPos - m.yPos);
                return d;
            }
            else
            {
                return 0;
            }
        }
        public override string ToString()
        {
            return "MU : " + xPos + "," + yPos + "," + Health;
        }

        public Direction DirectionTo(Unit u)
        {
            if (u.GetType() == typeof(SpecialForces))
            {
                SpecialForces m = (SpecialForces)u;
                if (m.xPos < xPos)
                {
                    return Direction.North;
                }
                else if (m.xPos < xPos)
                {
                    return Direction.South;
                }
                else if (m.yPos < yPos)
                {
                    return Direction.West;
                }
                else
                {
                    return Direction.East;
                }
            }
            else
            {
                return Direction.North;
            }
        }
    }
}
