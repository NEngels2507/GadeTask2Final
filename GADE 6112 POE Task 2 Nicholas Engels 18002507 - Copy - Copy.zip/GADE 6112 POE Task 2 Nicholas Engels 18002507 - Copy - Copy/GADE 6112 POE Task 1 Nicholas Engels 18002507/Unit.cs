﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_6112_POE_Task_1_Nicholas_Engels_18002507
{
    public enum Direction { North, East, South, West};

    public abstract class Unit
    {
        protected int XPos;
        protected int YPos;
        protected int xPosMove;
        protected int yPosMove;
        protected int Health;
        protected int Speed;
        protected int Attack;
        protected int Range;
        protected int Faction;
        protected string Image;
        protected string Name;

        abstract public void Move(Direction direction);
        abstract public void Combat(Unit u);
        abstract public bool InRange(Unit u);
        abstract public Unit Closest(Unit[] units);
        abstract public bool IsDead();
        //abstract public string toString();

    }
}
