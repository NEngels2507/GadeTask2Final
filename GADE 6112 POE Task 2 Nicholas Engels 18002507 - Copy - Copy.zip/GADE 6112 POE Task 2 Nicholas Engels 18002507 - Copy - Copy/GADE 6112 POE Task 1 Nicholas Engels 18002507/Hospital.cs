﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE_6112_POE_Task_1_Nicholas_Engels_18002507
{
    public class Hospital : Unit
    {
        public int xPos//This saves the X position of the Melee Unit
        {
            get { return XPos; }
            set { XPos = value; }
        }

        public int yPos//This saves the X position of the Melee Unit
        {
            get { return YPos; }
            set { YPos = value; }
        }

        public int XPosMove//This saves the X position of the Melee Unit
        {
            get { return xPosMove; }
            set { xPosMove = value; }
        }

        public int YPosMove//This saves the X position of the Melee Unit
        {
            get { return yPosMove; }
            set { yPosMove = value; }
        }

        public new int Health//This saves the X position of the Melee Unit
        {
            get { return Health; }
            set { Health = value; }
        }

        public new int Speed//This saves the X position of the Melee Unit
        {
            get { return Speed; }
            set { Speed = value; }
        }

        public new int Attack//This saves the X position of the Melee Unit
        {
            get { return Attack; }
            set { Attack = value; }
        }

        public new int Range//This saves the X position of the Melee Unit
        {
            get { return Range; }
            set { Range = value; }
        }

        public new int Faction//This saves the X position of the Melee Unit
        {
            get { return Faction; }
            set { Faction = value; }
        }

        public new string Image//This saves the X position of the Melee Unit
        {
            get { return Image; }
            set { Image = value; }
        }


        public new string Name//This saves the X position of the Melee Unit
        {
            get { return Name; }
            set { Name = value; }
        }

        public Hospital(int x, int y, int health, int attack, int speed, int range, int faction, string image, string name)
        {
            xPos = x;
            yPos = y;
            Health = health;
            Speed = speed;
            Attack = attack;
            Range = range;
            Faction = faction;
            Image = image;
            Name = name;
        }

        public override void Move(Direction d)
        {
            throw new NotImplementedException();
        }

        public override void Combat(Unit u)
        {
            throw new NotImplementedException();
        }

        public override bool InRange(Unit u)
        {
            throw new NotImplementedException();
        }

        public override Unit Closest(Unit[] units)
        {
            throw new NotImplementedException();
        }

        public override bool IsDead()
        {
            throw new NotImplementedException();
        }

        private int DistanceTo(Unit u)
        {
            throw new NotImplementedException();
        }
        public override string ToString()
        {
            return "MU : " + xPos + "," + yPos + "," + Health;
        }

        public Direction DirectionTo(Unit u)
        {
            throw new NotImplementedException();
        }
    }
}
